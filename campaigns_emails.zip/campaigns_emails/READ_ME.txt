@author: Joan Villariaza

************************
Please make sure to replace 
`name` with the real name of the user, 
`referrer@vit.sg` with the correct name of the refferer, and  
`recipient@vit.sg` with the correct email address of the recipient.