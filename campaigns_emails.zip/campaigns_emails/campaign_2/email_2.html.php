<p></p>
<div style="width: 600px; margin: 0px auto 0px; font-family: arial,helvetica,sans-serif; font-size: 14px;">
	<div style="padding: 0 0 20px 0; border-bottom: 2px solid #AC8D8A;">
		<img style="display: block; margin-left: auto; margin-right: auto;" src="http://riglist.com/email-system/sg/images/vitamin.sg-header.jpg" height="172" width="600" />
	</div>
	<h1 style="text-align: center; border-bottom: 2px solid #AC8D8A; padding: 10px 0;">
		<span style="color: #1CB064; font-style: italic;">It&#39;s a bottle of Sundown Naturals for <b style="color: red">$1 Only</b></span>
	</h1>
	<p>
		<div style="height: 146px;">
			<img src="http://vit.sg/image/main-banner.png">
		</div>
	</p>
	
	<p>Dear Name,</p>
	<p>Name cares for your health so he referred you to us to get a Sundown Naturals high potency vitamin C for as low as $1, which originally costs $15.70.</p>
	<p>We want you to boost your immune system, so we want you to enjoy a special trial offer.</p>
	<p>Simply click the <b>&#34;Yes, I Want It!&#34;</b> button and we will directly ship your immune booster to your place. That&#39;s it!</p>
	<p>We wish you a great health for a more vibrant life!</p>
	
	<p><center>
		<a href="http://vit.sg/index.php?route=campaign/thank_you&ref=<?php echo $_GET['ref']?>&email=<?php echo $_GET['email']?>&cpn=2" style="appearance: button; -moz-appearance: button; -webkit-appearance: button; text-decoration: none; font: menu; display: inline-block; padding: 10px 16px; color: #ffffff; border: none; background-color: #1CB064; background-position: top left; text-decoration: none; background-repeat: no-repeat; font-size: 11pt;">Yes, I Want It!</a>
	</center></p>
	<div style="padding: 20px 0 10px 0; border-bottom: 2px solid #1CB064;">
		<em>Vitamin.sg is the leading distributor for health and nutritional products in South East Asia. </em>
	</div>
	<p><img src="http://vit.sg/image/bottom_part_of_the_email.png" style="zoom: 87%" /></p>
</div>